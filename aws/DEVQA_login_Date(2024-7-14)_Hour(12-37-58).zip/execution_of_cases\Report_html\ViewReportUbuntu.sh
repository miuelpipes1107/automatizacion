run allure serve

